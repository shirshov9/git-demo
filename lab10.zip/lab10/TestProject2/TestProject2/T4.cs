﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab9._2
{
    internal class T4
    {
        private IWebDriver driver;
        public T4(IWebDriver inputdriver)
        {
            driver = inputdriver;
        }
        public void T44()
        {
            driver.FindElement(By.XPath("/html/body/div[1]/div[3]/div[2]/div[1]/div[3]/div[1]/div/div[2]/div[1]/div/div/div[3]/div[1]/button")).Click();
        }
    }
}