﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab9._2
{
    internal class T3
    {
        private IWebDriver driver;
        public T3(IWebDriver inputdriver)
        {
            driver = inputdriver;
        }
        public void T33()
        {
            driver.FindElement(By.XPath("/html/body/div[1]/div[3]/div[2]/div[2]/div/div/div[2]/ul/li[1]/div/div/div[2]/p[2]/a")).Click();

        }
    }
}