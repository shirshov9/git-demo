using lab9._2;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;


namespace lab9._2
{
    public class Tests
    {
        [Test]
        public void Gesha()
        {
            IWebDriver driver = new ChromeDriver("C:\\webdriver\\chromedriver.exe");
            driver.Url = "https://aldebaran.ru/";

            T1 Elem1 = new T1(driver);
            Elem1.T11();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);

            T2 Elem2 = new T2(driver);
            Elem2.T22();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);

            T3 Elem3 = new T3(driver);
            Elem3.T33();

            T4 Elem4 = new T4(driver);
            Elem4.T44();
        }
    }
}