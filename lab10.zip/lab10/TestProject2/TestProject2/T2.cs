﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab9._2
{
    internal class T2
    {
        private IWebDriver driver;
        public T2(IWebDriver inputdriver)
        {
            driver = inputdriver;
        }
        public void T22()
        {
            driver.FindElement(By.XPath("/html/body/div[1]/div[3]/div[2]/div[2]/div/div/div[1]/ul[2]/li[4]/a")).Click();
        }
    }
}
