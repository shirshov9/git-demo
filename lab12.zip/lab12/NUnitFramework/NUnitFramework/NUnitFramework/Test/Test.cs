﻿using NUnit.Framework;
using OpenQA.Selenium;

namespace NUnitFramework
{
    [TestFixture]
    public class SmokeTests
    {
        private Steps.Steps steps = new Steps.Steps();
        
        private const int REPOSITORY_RANDOM_POSTFIX_LENGTH = 6;

        [SetUp]
        public void Init()
        {
            steps.InitBrowser();
        }

        [TearDown]
        public void Cleanup()
        {
            steps.CloseBrowser();
        }

        [Test]
        public void ReedOnline()
        {
            steps.ReedOnline();
        }

        [Test]
        public void PostponeBookUser()
        {
            steps.PostponeBook();
        }

        [Test]
        public void ReadedBookUser()
        {
            steps.Readed();
        }

        [Test]
        public void Short()
        {
            steps.Short();
        }
        [Test]
        public void Gesha()
        {
            steps.Gesha();
        }

        [Test]
        public void Mid()
        {
            steps.Mid();
        }

        [Test]
        public void Global()
        {
            steps.Global();
        }

        [Test]
        public void Book()
        {
            steps.Book();
        }
        [Test]
        public void Span()
        {
            steps.Span();
        }

    }
}
