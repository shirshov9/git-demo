﻿using NUnit.Framework;
using OpenQA.Selenium;

namespace NUnitFramework
{
    [TestFixture]
    public class SmokeTests
    {
        private Steps.Steps steps = new Steps.Steps();
        
        private const int REPOSITORY_RANDOM_POSTFIX_LENGTH = 6;

        [SetUp]
        public void Init()
        {
            steps.InitBrowser();
        }

        [TearDown]
        public void Cleanup()
        {
            steps.CloseBrowser();
        }

        [Test]
        public void ReedOnline()
        {
            steps.ReedOnline();
        }

        [Test]
        public void PostponeBookUser()
        {
            steps.PostponeBook();
        }

        [Test]
        public void ReadedBookUser()
        {
            steps.Readed();
        }

        [Test]
        public void Short()
        {
            steps.Short();
        }

        [Test]
        public void AwardComment()
        {
            steps.AwardComment();
        }

        [Test]
        public void AudioBook()
        {
            steps.AudioBook();
        }

        [Test]
        public void BookAward()
        {
            steps.BookAward();
        }

        [Test]
        public void BookCommentAdd()
        {
            steps.BookCommentAdd();
        }

        [Test]
        public void BookComplain()
        {
            steps.BookComplain();
        }
    }
}
