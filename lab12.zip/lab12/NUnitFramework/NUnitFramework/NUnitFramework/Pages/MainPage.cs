﻿using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;
 using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.DevTools.V106.Network;

namespace NUnitFramework.Pages
{
    public class MainPage
    {
        private const string BASE_URL = "https://aldebaran.ru/";

        private IWebDriver _driver;

        public MainPage(IWebDriver driver)
        {
            this._driver = driver;
            PageFactory.InitElements(this._driver, this);
        }

        public void OpenPage()
        {
            _driver.Navigate().GoToUrl(BASE_URL);
        }

        private readonly By InputField = By.XPath("/html/body/div[1]/div[1]/div/div[4]/div/form/input[1]");
        private readonly By Lupa = By.XPath("/html/body/div[1]/div[1]/div/div[4]/div/form/input[2]");

        private readonly By BookMenu = By.XPath("//a[text()='Книги']");
        private readonly By Book = By.XPath("//a[text()='В руках богини']");
        private readonly By BookComment = By.XPath("//*[@id='cover_img88838990']");
        private readonly By BookCommentPlus = By.XPath("//*[@id='recense__wrap']/div[1]/div[5]/div/span/a[1]");
        private readonly By Poster = By.XPath("/html/body/div[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div/span/img");
        private readonly By Postpone = By.XPath("//span[text()='Отложить']");

        private readonly By Readed = By.XPath("//span[text()='Читал']");

        private readonly By ShortInMenu = By.XPath("//a[text()='Краткое содержание']");
        private readonly By ShortButtom = By.XPath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div[2]/div[2]/div/ul/div[2]/div[2]/div[2]");
        private readonly By ShortBook = By.XPath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div[2]/div[2]/div/ul/div[1]/div/div[11]/li/div/div/div[2]/p[2]/a");

        private readonly By AudioBookMenu = By.XPath("//*[@id='main']/div[1]/div/div[2]/ul/li[2]/a");
        private readonly By MostDebate = By.XPath("//*[@id='most_debate_link_id']");
        private readonly By BookBoss = By.XPath("//*[@id='wlist1']/ul/li[1]/div/div/div[2]/p[2]/a");
        private readonly By PlayButton = By.XPath("//*[@id='mep_0']/div/div[3]/div[1]/button");

        private readonly By BookStudent = By.XPath("//*[@id='cover_img84521741']");
        private readonly By BookAwardFour = By.XPath("//*[@id='4']/span");

        private readonly By BookDiamond = By.XPath("//*[@id='cover_img95547233']");
        private readonly By CommentNickname = By.XPath("//*[@id='nickname']");
        private readonly By CommentBody = By.XPath("//*[@id='message']");
        private readonly By CommentAddButton = By.XPath("/html/body/div[1]/div[3]/div[2]/div[1]/div[3]/div[3]/div/form/button");

        private readonly By BookMy = By.XPath("//*[@id='cover_img96680542']");
        private readonly By Complain = By.XPath("//*[@id='main_content']/div[2]/div[2]/a");
        private readonly By ComplainEmail = By.XPath("//*[@id='main_content']/div[2]/div/form/div[1]/div[2]/input");
        private readonly By ComplainBody = By.XPath("//*[@id='main_content']/div[2]/div/form/div[2]/div[2]/textarea");
        private readonly By ComplainButtonSend = By.XPath("//*[@id='main_content']/div[2]/div/form/div[4]/input");


        public void Online()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).SendKeys("Другой мир. Зеркало Темновита");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Lupa).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public void PostponeBook()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookMenu).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Book).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Poster).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Postpone).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public void ReadedBook()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookMenu).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Book).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Poster).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Readed).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public void Short()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(ShortInMenu).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(ShortButtom).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(ShortBook).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public void AwardComment()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).SendKeys("Ткущие мрак");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Lupa).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookComment).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookCommentPlus).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }
        
        public void AudioBook()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(AudioBookMenu).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(MostDebate).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookBoss).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(PlayButton).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }
        
        public void BookAward()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).SendKeys("Учитель и ученица");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Lupa).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookStudent).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookAwardFour).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public void BookCommentAdd()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).SendKeys("Алмазные грани");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Lupa).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookDiamond).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(CommentNickname).SendKeys("Jack");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(CommentBody).SendKeys("Не читал, но думаю норм");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(CommentAddButton).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public void BookComplain()
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(InputField).SendKeys("Будь моей");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Lupa).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(BookMy).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(Complain).Click();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(ComplainEmail).SendKeys("testemail@mail.ru");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            _driver.FindElement(ComplainBody).SendKeys("книга такая себе");
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            //_driver.FindElement(ComplainButtonSend).Click(); <-- при отправке жалобы пишет ошибку капчи, но самой капчи нет это !БАГ! сайта!!!
        }
    }
}
